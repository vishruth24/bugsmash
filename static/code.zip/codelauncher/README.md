# Bugsmash Server
Server which compiles C code and displays output in the screen.

## Technology
Flask

## Author 
Vishruth M

#include<stdio.h>
#include<string.h>
#define N 5
int main()
{ int t;
 printf("Test cases:");
 scanf("%d",&t);
 while(t--) {
 int n=N,m,i,j,flag;
 printf("Number of items in each floor\n");
 scanf("%d",&m);
 char arr [n+1][m+1];
 char list[(n*m)+1];
 int hash[n+1][125];
 memset(hash,0,sizeof(hash));
 for(i=0;i<n;i++)
 {scanf("%s",arr[i]);
 for(j=0;j<m;j++)
 hash[i][arr[i][j]]++; }
 scanf("%s",list);
 int len = strlen(list);
 int loop = 0;
 flag = 0;
 for(i=0;i<=len;i++)
 {loop = loop%n;
  if(hash[loop][list[i]]>0)
 {hash[loop][list[i]]--; }
  else{flag = 1;
  break;}
  loop++;
   }if(flag)
   printf("No\n");
   else
   printf("Yes\n");
}return 0;
}

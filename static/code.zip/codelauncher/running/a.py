while True:
 print(5)




